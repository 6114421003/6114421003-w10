
<?php $__env->startSection('title'); ?> BikeShop | เพิ่มข้อมูลสินค้า <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
    <?php echo Form::open(array('action' => 'TitleController@insert', 'method'=>'post', 'enctype' => 'multipart/form-data')); ?>


    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($error); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    <div class="panel-heading">
        <div class="panel-title"><h3>เพิ่มข้อมูลสินค้า</h3></div>
    </div>
    <div class="panel-body">
        <table>
        <tr>
                <td><?php echo e(Form::label('nameth', 'ชื่อสินค้า')); ?></td>
                <td><?php echo e(Form::text('nameth', Request::old('nameth'), ['class' => 'form-control'])); ?></td>
            </tr>
            <tr>
                <td><?php echo e(Form::label('nameen', 'ชื่อสินค้า')); ?></td>
                <td><?php echo e(Form::text('nameen', Request::old('nameen'), ['class' => 'form-control'])); ?></td>
            </tr>
        </table>
    </div>
    <div class="panel-footer">
      <button type="reset" class="btn btn-danger">ยกเลิก</button>
      <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> บันทึก</button>
    </div>
    <?php echo Form::close(); ?>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\PP\work\gadgetpro\resources\views/title/add.blade.php ENDPATH**/ ?>