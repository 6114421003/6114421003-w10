<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ChartJSController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/faculty', 'FacultyController@index');
Route::post('/faculty/search', 'FacultyController@search');
Route::get('/faculty/search', 'FacultyController@search');
Route::get('/faculty/edit/{id?}', 'FacultyController@edit');
Route::post('/faculty/update', 'FacultyController@update');
Route::post('/faculty/insert', 'FacultyController@insert');
Route::get('/faculty/remove/{id}', 'FacultyController@remove');



Route::get('/research', 'ResearchController@index');
Route::post('/research/search', 'ResearchController@search');
Route::get('/research/search', 'ResearchController@search');
Route::get('/research/edit/{id?}', 'ResearchController@edit');
Route::post('/research/update', 'ResearchController@update');
Route::post('/research/insert', 'ResearchController@insert');
Route::get('/research/remove/{id}', 'ResearchController@remove');



Route::get('/researcher', 'ResearcherController@index');
Route::post('/researcher/search', 'ResearcherController@search');
Route::get('/researcher/search', 'ResearcherController@search');
Route::get('/researcher/edit/{id?}', 'ResearcherController@edit');
Route::post('/researcher/update', 'ResearcherController@update');
Route::post('/researcher/insert', 'ResearcherController@insert');
Route::get('/researcher/remove/{id}', 'ResearcherController@remove');


Route::get('/research_fund_provider', 'Research_fund_providerController@index');
Route::post('/research_fund_provider/search', 'Research_fund_providerController@search');
Route::get('/research_fund_provider/search', 'Research_fund_providerController@search');
Route::get('/research_fund_provider/edit/{id?}', 'Research_fund_providerController@edit');
Route::post('/research_fund_provider/update', 'Research_fund_providerController@update');
Route::post('/research_fund_provider/insert', 'Research_fund_providerController@insert');
Route::get('/research_fund_provider/remove/{id}', 'Research_fund_providerController@remove');


Route::get('/title', 'TitleController@index');
Route::post('/title/search', 'TitleController@search');
Route::get('/title/search', 'TitleController@search');
Route::get('/title/edit/{id?}', 'TitleController@edit');
Route::post('/title/update', 'TitleController@update');
Route::post('/title/insert', 'TitleController@insert');
Route::get('/title/remove/{id}', 'TitleController@remove');


Route::get('chart-js', [App\Http\Controllers\ChartJSController::class, 'index']);


Route::get('researcherJS', [ App\Http\Controllers\ ResearcherJSController::class, 'index']);

Route::get('facultyJS', [ App\Http\Controllers\ FacultyJSController::class, 'index']);


Route::get('research_fund_providerJS', [ App\Http\Controllers\ Research_fund_providerJSController::class, 'index']);

Route::get('titleJS', [ App\Http\Controllers\ titleJSController::class, 'index']);