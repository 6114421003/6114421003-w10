<?php

namespace App\Http\Controllers;

use App\Research;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ChartJSController extends Controller
{
   public function index(){
       $researchs = DB::table('research')
       ->select(DB::raw("month(contract_signed) as month_signed"), DB::raw("sum(budget) as total_budget"))
       ->distinct()
       ->whereRaw('year(contract_signed) = ?', [2020])
       ->groupByRaw('month_signed')
       ->get();

       $data = [];

        foreach($researchs as $row){
            $data['label'][] = $row->month_signed;
            $data['data'][] = (int)$row->total_budget;
        }
        $data['chart_data'] = json_encode($data);
        return view('chart-js',$data);


    }
}
