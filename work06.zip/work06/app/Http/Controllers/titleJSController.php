<?php

namespace App\Http\Controllers;

use App\Researcher;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class titleJSController extends Controller

{
    public function index(){
        $researcher = DB::table('title')
        ->select(DB::raw('num'), DB::raw("nameth"))
        ->where('nameth', '<>', 1)
        ->get();
 
        $data = [];
 
         foreach($researcher as $row){
             $data['label'][] = $row->nameth;
             $data['data'][] = (int)$row->num;
         }
         $data['chart_data'] = json_encode($data);
         return view('titleJS',$data);
 
 
     }
 }