<?php

namespace App\Http\Controllers;

use App\Researcher;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ResearcherJSController extends Controller
{
    public function index(){
        $researcher = DB::table('researcher')
        ->select(('ttl_id'),DB::raw('count(ttl_id) as count_title'))
        ->whereraw('fct_id = ?', [9])
        ->groupBy('ttl_id')
        ->get();
 
        $data = [];
 
         foreach($researcher as $row){
             $data['label'][] = $row->ttl_id;
             $data['data'][] = (int)$row->count_title;
         }
         $data['chart_data'] = json_encode($data);
         return view('researcherJS',$data);
 
 
     }
 }


