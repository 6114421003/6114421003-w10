<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Research_fund_provider;
use App\Category;

class Research_fund_providerController extends Controller
{
    var $rp = 20;
    
    public function index() {
        $research_fund_providers = Research_fund_provider::paginate($this->rp);
        return view('research_fund_provider/index', compact('research_fund_providers'));
    }
    public function edit($id = null) {
        $categories = Category::pluck('name', 'id')->prepend('เลือกรายการ', '');
        if($id) {
            $research_fund_provider = Research_fund_provider::where('id', $id)->first();
            return view('research_fund_provider/edit')
                ->with('research_fund_provider', $research_fund_provider)
                ->with('categories', $categories);
        } else {
            return view('research_fund_provider/add')
                ->with('categories', $categories);
        }
    
    }
    public function update(Request $request) {
        $rules = array(
            'nameth' => 'required',

        );
        $messages = array(
            'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
            'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
        );
        $id = $request->input('id');
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('research_fund_provider/edit/'.$id)
                ->withErrors($validator)
                ->withInput();
        }
        $research_fund_provider = Research_fund_provider::find($id);
        $research_fund_provider->nameth = $request->input('nameth');
        $research_fund_provider->nameen = $request->input('nameen');
        $research_fund_provider->fund = $request->input('fund');
        $research_fund_provider->save();
        return redirect('research_fund_provider')
            ->with('ok', true)
            ->with('msg', 'บันทึกข้อมูลเรียบร้อยแล้ว');
    
    }
    public function insert(Request $request) {
        $rules = array(
            'nameth' => 'required',
        );
        $messages = array(
            'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
            'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
        );
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('research_fund_provider/edit')
                ->withErrors($validator)
                ->withInput();
        }
        $research_fund_provider = new Research_fund_provider();
        $research_fund_provider->nameth = $request->input('nameth');
        $research_fund_provider->nameen = $request->input('nameen');
        $research_fund_provider->fund = $request->input('fund');
        $research_fund_provider->save();
        return redirect('research_fund_provider')
            ->with('ok', true)
            ->with('msg', 'เพิ่มข้อมูลเรียบร้อยแล้ว');
    }
    public function search(Request $request) {
        $query = $request->input('q');
        if($query) {
            $research_fund_providers = Research_fund_provider::where('nameth', 'like', '%'.$query.'%')
                ->orWhere('nameth', 'like', '%'.$query.'%')
                ->paginate($this->rp);

        } else {
            $research_fund_providers = Research_fund_provider::paginate($this->rp);
        }
        return view('research_fund_provider/index', compact('research_fund_providers'));

    }

    public function remove($id) {
        Research_fund_provider::find($id)->delete();
        return redirect('research_fund_provider')
            ->with('ok', true)
            ->with('msg', 'ลบข้อมูลสำเร็จ');
    }
}

