<?php

namespace App\Http\Controllers;

use App\Researcher;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Research_fund_providerJSController extends Controller
{
    public function index(){
        $researcher = DB::table('research_fund_provider')
        ->select(DB::raw('fund'), DB::raw("nameth"))
        ->where('nameth', '<>', 1)
        ->get();
 
        $data = [];
 
         foreach($researcher as $row){
             $data['label'][] = $row->nameth;
             $data['data'][] = (int)$row->fund;
         }
         $data['chart_data'] = json_encode($data);
         return view('research_fund_providerJS',$data);
 
 
     }
 }