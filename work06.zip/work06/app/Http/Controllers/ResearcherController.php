<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Researcher;
use App\Category;

class ResearcherController extends Controller
{
    var $rp = 20;
    
    public function index() {
        $researchers = Researcher::paginate($this->rp);
        return view('researcher/index', compact('researchers'));
    }
    public function edit($id = null) {
        $categories = Category::pluck('name', 'id')->prepend('เลือกรายการ', '');
        if($id) {
            $researcher = Researcher::where('id', $id)->first();
            return view('researcher/edit')
                ->with('researcher', $researcher)
                ->with('categories', $categories);
        } else {
            return view('researcher/add')
                ->with('categories', $categories);
        }
    
    }
    public function update(Request $request) {
        $rules = array(
            'ttl_id' => 'required',
            'fname' => 'required',
        );
        $messages = array(
            'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
            'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
        );
        $id = $request->input('id');
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('researcher/edit/'.$id)
                ->withErrors($validator)
                ->withInput();
        }
        $researcher = Researcher::find($id);
        $researcher->ttl_id = $request->input('ttl_id');
        $researcher->fname = $request->input('fname');
        $researcher->lname = $request->input('lname');
        $researcher->fct_id = $request->input('fct_id');
        $researcher->save();
        return redirect('researcher')
            ->with('ok', true)
            ->with('msg', 'บันทึกข้อมูลเรียบร้อยแล้ว');
    
    }
    public function insert(Request $request) {
        $rules = array(
            'ttl_id' => 'required',
            'fname' => 'required',
        );
        $messages = array(
            'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
            'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
        );
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('researcher/edit')
                ->withErrors($validator)
                ->withInput();
        }
        $researcher = new Researcher();
        $researcher->ttl_id = $request->input('ttl_id');
        $researcher->fname = $request->input('fname');
        $researcher->lname = $request->input('lname');
        $researcher->fct_id = $request->input('fct_id');
        $researcher->save();
        return redirect('researcher')
            ->with('ok', true)
            ->with('msg', 'เพิ่มข้อมูลเรียบร้อยแล้ว');
    }
    public function search(Request $request) {
        $query = $request->input('q');
        if($query) {
            $researchers = Researcher::where('ttl_id', 'like', '%'.$query.'%')
                ->orWhere('ttl_id', 'like', '%'.$query.'%')
                ->paginate($this->rp);

        } else {
            $researchers = Researcher::paginate($this->rp);
        }
        return view('researcher/index', compact('researchers'));

    }

    public function remove($id) {
        researcher::find($id)->delete();
        return redirect('researcher')
            ->with('ok', true)
            ->with('msg', 'ลบข้อมูลสำเร็จ');
    }
}
