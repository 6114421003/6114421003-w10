<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Faculty;
use App\Category;

class FacultyController extends Controller
{
    
        var $rp = 10;
    
        public function index() {
            $facultys = Faculty::paginate($this->rp);
            return view('faculty/index', compact('facultys'));
        }
        public function edit($id = null) {
            $categories = Category::pluck('name', 'id')->prepend('เลือกรายการ', '');
            if($id) {
                $faculty = Faculty::where('id', $id)->first();
                return view('faculty/edit')
                    ->with('faculty', $faculty)
                    ->with('categories', $categories);
            } else {
                return view('faculty/add')
                    ->with('categories', $categories);
            }
        
        }
        public function update(Request $request) {
            $rules = array(
                'nameth' => 'required',
                'nameen' => 'required',
            );
            $messages = array(
                'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
                'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
            );
            $id = $request->input('id');
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return redirect('faculty/edit/'.$id)
                    ->withErrors($validator)
                    ->withInput();
            }
            $faculty = Faculty::find($id);
            $faculty->nameth = $request->input('nameth');
            $faculty->nameen = $request->input('nameen');
            $faculty->save();
            return redirect('faculty')
                ->with('ok', true)
                ->with('msg', 'บันทึกข้อมูลเรียบร้อยแล้ว');
        
        }
        public function insert(Request $request) {
            $rules = array(
                'nameth' => 'required',
                'nameen' => 'required',
            );
            $messages = array(
                'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
                'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
            );
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return redirect('faculty/edit')
                    ->withErrors($validator)
                    ->withInput();
            }
            $faculty = new Faculty();
            $faculty->nameth = $request->input('nameth');
            $faculty->nameen = $request->input('nameen');
            $faculty->save();
            return redirect('faculty')
                ->with('ok', true)
                ->with('msg', 'เพิ่มข้อมูลเรียบร้อยแล้ว');
        }
        public function search(Request $request) {
            $query = $request->input('q');
            if($query) {
                $facultys = Faculty::where('nameth', 'like', '%'.$query.'%')
                    ->orWhere('nameth', 'like', '%'.$query.'%')
                    ->paginate($this->rp);
    
            } else {
                $facultys = Faculty::paginate($this->rp);
            }
            return view('faculty/index', compact('facultys'));
    
        }
    
        public function remove($id) {
            Faculty::find($id)->delete();
            return redirect('faculty')
                ->with('ok', true)
                ->with('msg', 'ลบข้อมูลสำเร็จ');
        }
}
