<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Research;
use App\Category;

class ResearchController extends Controller
{
    var $rp = 20;
    
    public function index() {
        $researchs = Research::paginate($this->rp);
        return view('research/index', compact('researchs'));
    }
    public function edit($id = null) {
        $categories = Category::pluck('name', 'id')->prepend('เลือกรายการ', '');
        if($id) {
            $research = Research::where('id', $id)->first();
            return view('research/edit')
                ->with('research', $research)
                ->with('categories', $categories);
        } else {
            return view('research/add')
                ->with('categories', $categories);
        }
    
    }
    public function update(Request $request) {
        $rules = array(
            'nameth' => 'required',
            'nameen' => 'required',
        );
        $messages = array(
            'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
            'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
        );
        $id = $request->input('id');
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('research/edit/'.$id)
                ->withErrors($validator)
                ->withInput();
        }
        $research = Research::find($id);
        $research->nameth = $request->input('nameth');
        $research->nameen = $request->input('nameen');
        $research->budget = $request->input('budget');
        $research->rfp_id = $request->input('rfp_id');
        $research->contract_signed = $request->input('contract_signed');
        $research->save();
        return redirect('research')
            ->with('ok', true)
            ->with('msg', 'บันทึกข้อมูลเรียบร้อยแล้ว');
    
    }
    public function insert(Request $request) {
        $rules = array(
            'nameth' => 'required',
            'nameen' => 'required',
        );
        $messages = array(
            'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
            'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
        );
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('research/edit')
                ->withErrors($validator)
                ->withInput();
        }
        $research = new Research();
        $research->nameth = $request->input('nameth');
        $research->nameen = $request->input('nameen');
        $research->budget = $request->input('budget');
        $research->rfp_id = $request->input('rfp_id');
        $research->contract_signed = $request->input('contract_signed');
        $research->save();
        return redirect('research')
            ->with('ok', true)
            ->with('msg', 'เพิ่มข้อมูลเรียบร้อยแล้ว');
    }
    public function search(Request $request) {
        $query = $request->input('q');
        if($query) {
            $researchs = Research::where('nameth', 'like', '%'.$query.'%')
                ->orWhere('nameth', 'like', '%'.$query.'%')
                ->paginate($this->rp);

        } else {
            $researchs = Research::paginate($this->rp);
        }
        return view('research/index', compact('researchs'));

    }

    public function remove($id) {
        Research::find($id)->delete();
        return redirect('research')
            ->with('ok', true)
            ->with('msg', 'ลบข้อมูลสำเร็จ');
    }
}

